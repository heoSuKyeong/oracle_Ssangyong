-- review.sql

INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'오늘 나의 해방일지 프리퀄인 범죄도시2를 보고왔습니다.
구씨가 왜 도랑을 뛰어넘고 옷위로 들어나는 뛰어난 피지컬을 가지고도 산포시에서 밭일과 싱크대 일을 하며 폐인처럼 술만 마시고 살게됐는지 잘 느껴지는 작품이었습니다.

보통깡패 아니었던거 같았는데 프리퀄에 다담계있네요ㅎ

많은 분들이 구씨의 프리퀄 꼭 감상하시고 드라마에 더 몰입하실 수 있었으면 합니다. 강추',
'이정호',
TO_DATE('05-17-2022 22:35','MM-DD-YYYY HH24:MI'),
255,
43,
'1'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
1,
'15세 영화라니. 정말 기가 막힙니다. 이제 수위가 사라졌나요. 사람은 보고 들은 것에 영향을 받습니다.  왜 
이런 잔인한 영화를 즐기는지. 우리 인성이  심각할 정도로 병들어가고  있다는 증거입니다. 쾌락을 위해서는  
괜찮다고요? 마음이  완악해지고 잔인해집니다. 폭력적 인간성이 내재하게 됩니다. 15세라니...',
'착한사람',
TO_DATE('06-03-2022 02:00','MM-DD-YYYY HH24:MI'),
224,
78,
'1'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
3,
'아무리  흥행을 위해서라지만 너무 잔인합니다. 왜 우리 한국 영화가 이리도 잔인하게 연출될까요. 재밌자고, 그냥 
웃자고 한다  해도  정말 잔인합니다. 사람의 인성이 무섭게 파괴됩니다. 사회각종  범죄 그냥 그대로 입니다. 어느 
순간 우린 이런 잔혹한 영화를 보는데도 무감각, 무덤덤 해져갑니다.  그 옛날 박한상군이 자기 부모 죽일때 영화를 
보고 그대로 따라 했다하여 큰 충격을 주었는데..."악은 모양이라도 버려라"',
'통찰력',
TO_DATE('05-26-2022 17:36','MM-DD-YYYY HH24:MI'),
202,
73,
'1'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
9,
'요새 나오는 마블 영화보다 백배는 재미있게 본 영화',
'공간창조',
TO_DATE('06-22-2022 15:30','MM-DD-YYYY HH24:MI'),
251,
25,
'2'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'방금 보고 왔습니다.
곳곳에서 울컥 울컥!!
36-7년전 1편과 이야기를 이어 가면서도
새로운 신화를 창조하네요.
실제 후드암을 앓고 있는 아이스맨(발 킬머)이
있는 그대로 출연한 것도 감동~ㅠㅠ
영화와 아날로그 액션에 대한
믿음을 가진 마지막 배우 톰 크루즈의 인생 역작입니다!!
꼭 영화관에서 보세요.
비행 장면은 말해 뭐해~~
항공모함 위에서의 오프닝 스퀀스가 짧아서 
오히려 이쉽네요.
탑건의 전설을 제대로 이었다고 봅니다!!!',
'조기성',
TO_DATE('06-22-2022 13:27','MM-DD-YYYY HH24:MI'),
167,
12,
'2'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'톰 형이 이 영화를 끝으로 은퇴한다해도 아쉬움이 없을 정도로 완벽하다. 탑건과 미션임파서블을 결합해서 
제리브룩하이머가 최상의 퀄리티로 제작했다. 스토리상의 약간의 아쉬움도 잊게 할만큼 압도적인 
비행전투씬만으로도 흥분이 가라앉지 않는다. 이게 헐리우드다',
'발라모굴리스',
TO_DATE('06-18-2022 21:13','MM-DD-YYYY HH24:MI'),
129,
14,
'2'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'멋집니다.

환상적 물의 길에서
가족과 부족을 지키기 위한
의와 불의의 싸움.

요즘
끝간데 모르고 미쳐 날뛰는
넘들에게

삶이란 무엇인가를
가르쳐주기 위해
한국에서 처음 개봉했나 봅니다.',
'써머스비',
TO_DATE('12-14-2022 17:21','MM-DD-YYYY HH24:MI'),
245,
52,
'3'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'10시 20분 영화 봄
이제끝남 ㅋㅋ
Cg가 ㅎㄷㄷ 하네요
이걸 어떻게 만들지 ...
꿈꾸다가 온 듯한 느낌',
'조용히좀',
TO_DATE('12-14-2022 13:47','MM-DD-YYYY HH24:MI'),
158,
36,
'3'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'우와ᆢ바다풍경이 정말 예술 환상적ㅜㅜ
이보다 더 아름다운 바다가 있을까 ~ 
3시간동안 힐링범벅하고 왔네요 
액션도 스토리도 군더더기 늘어짐 없이
너무재미있고 또 감동까지ᆢㅜ ㅜ
코로나시대에  우울한 추운겨울에  
환상적인 꿈꾸다온기분~
제임스카메론 감독과 같은시대를 사는게
영광이네요 감사합니다~',
'얌얌',
TO_DATE('12-14-2022 16:51','MM-DD-YYYY HH24:MI'),
150,
29,
'3'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'명량에 이어 한산. 2천만 관객 기대합니다. 충무공이시여. 이 나라의 모든 어두움과 패배주의를 당신의 위대한 
거북선 함대로 모두 격파하여 주시옵소서. ',
'불에미친사나이',
TO_DATE('05-07-2020 16:29','MM-DD-YYYY HH24:MI'),
613,
26,
'4'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'노를 저어주신 한 분 한 분 감사합니다. 보이지 않는 곳에서 힘써 주신 민초들이 계셨기에 지금의 우리가 있음을 
기억하겠습니다!!',
'씩씩이',
TO_DATE('07-29-2022 00:32','MM-DD-YYYY HH24:MI'),
473,
7,
'4'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'역사의식
민족혼을
일깨우는
영화가 되길 소망합니다',
'진',
TO_DATE('05-22-2021 07:21','MM-DD-YYYY HH24:MI'),
303,
15,
'4'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'유해진 배우 출연작은 언제나 옳아요~~
그래서 개봉하면 항상 온가족 보러가죠~
기대해요!!!',
'푸르니',
TO_DATE('11-26-2021 18:49','MM-DD-YYYY HH24:MI'),
127,
69,
'5'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
2,
'진심 1에 비해 재미없네요 ㅠ 혹시나 했더니 감독도 다른 감독입니다. 유머코드가 너무 어색하네요 ㅠ 좀 
아쉬웠습니다.',
'NEXT황새',
TO_DATE('09-16-2022 18:15','MM-DD-YYYY HH24:MI'),
54,
5,
'5'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
5,
'공조1 과 비교 기대를 너무했을까 별로다,.,전반적으로 진행 어설프다..연기력에 멋진 유해진,현빈과 나머지 
배우분들 너무 비교 되어서 일까???',
'friend',
TO_DATE('09-26-2022 15:16','MM-DD-YYYY HH24:MI'),
50,
4,
'5'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
7,
'완다누나가 다해먹고 완다누나가 끝내는 완다비전:대혼돈의멀티버스',
'김영창',
TO_DATE('05-04-2022 17:55','MM-DD-YYYY HH24:MI'),
58,
12,
'6'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
9,
'이 영화의 주인공은 닥터스트레인지가 아닙니다',
'엄준용',
TO_DATE('05-04-2022 20:33','MM-DD-YYYY HH24:MI'),
52,
11,
'6'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
5,
'마블도 큰일이다  엔드게임이후로 스토리라인을 살리지못하네',
'차우차우',
TO_DATE('05-06-2022 13:53','MM-DD-YYYY HH24:MI'),
52,
18,
'6'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'대통령을 제거하라!

메인카피  점수만 10점 준다! 시의적절하다.',
DEFAULT,
TO_DATE('07-27-2022 12:43','MM-DD-YYYY HH24:MI'),
1038,
113,
'7'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'시리즈 2편. 여사도 제거하라!
시리즈 3편. 법사, 도사도 제거하라!',
'깨몽',
TO_DATE('08-10-2022 17:09','MM-DD-YYYY HH24:MI'),
835,
57,
'7'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'이정재 정우성 23년만에 만났으면 무조건 봐야지..
거기다 이정재 첫 연출작 ㄷ ㄷ',
'유진',
TO_DATE('04-14-2022 11:29','MM-DD-YYYY HH24:MI'),
127,
19,
'7'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'자고로 나랏님이 멍청하면 어진 백성만 피곤하다는 사실을 새삶 깨닫게 됨~',
'thsksan2',
TO_DATE('11-23-2022 14:46','MM-DD-YYYY HH24:MI'),
388,
33,
'8'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'관람평을 원래 작성 안하는데 정말 재밌게 봐서 적게 되네요. 아역부터 모든 배우들 연기도 정말 훌륭하고 유해진님 
연기는 섬뜩할 정도 였습니다.  연기를 다들 잘하셔서 그런지 배우들 이미지에 캐릭터가 왜이렇게 잘맞던지ㅎㅎ 
실화를 바탕으로 시사하는 바가 많았네요. 서민은 봐도 못본척 들어도 못들은 척 해야 살 수 있는 그런 시대는 이제 
옛날 이야기이길 바라는 마음입니다. 몰입도 최고! 감정 이입이도 최고! 많은 생각을 하게 만든 영화입니다. 최근 
영화중 역대급이네요. 보시면 정말 후회 안합니다.~^^',
'kdh905',
TO_DATE('11-23-2022 13:24','MM-DD-YYYY HH24:MI'),
215,
17,
'8'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'올해 나온 한국 영화 중 젤 재밌게 봄ㅜ 유해진 왕연기 미쳤다;;믿고보세욧',
'권나연',
TO_DATE('11-23-2022 13:40','MM-DD-YYYY HH24:MI'),
173,
22,
'8'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
4,
'시간가는줄 알고 봤어요',
'광새벽',
TO_DATE('06-05-2022 02:04','MM-DD-YYYY HH24:MI'),
58,
11,
'9'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
2,
'방금봣는데 너무 재미없슴당',
'레오',
TO_DATE('06-01-2022 21:32','MM-DD-YYYY HH24:MI'),
51,
21,
'9'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
7,
'솔직히 저는  1시간 좀 지나자마자 졸았어요.  아이도 지루했는지 화장실간다고 나가서는 30분 밖에서 휴대폰 게임하고 왔다네요. 
재밌을 거라고 꼬셔서 끌고 왔는데...  기대에 못미쳐서인지 집에 오는 내내 영화얘기는 하나도 안하고 왔네요. 
너무 기대하고 보진 마셔요.',
'sunflower1119',
TO_DATE('06-01-2022 21:55','MM-DD-YYYY HH24:MI'),
41,
23,
'9'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
1,
'1편이 넘~ 재미있어서 큰 기대했는데 역대급으로 재미 없네요. 개연성도/줄거리도 없고....',
'judy',
TO_DATE('06-15-2022 18:16','MM-DD-YYYY HH24:MI'),
174,
44,
'10'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
1,
'겁나 오그라든다~ ㄷㄷㄷ
유치해 죽는줄... 중2병스러운 대사와 전개...',
'방영배',
TO_DATE('06-17-2022 01:09','MM-DD-YYYY HH24:MI'),
99,
12,
'10'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
4,
'1편 제작진 맞냐',
'마르코',
TO_DATE('06-15-2022 13:23','MM-DD-YYYY HH24:MI'),
93,
12,
'10'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'완전 내 취향.
건스 앤 로지스의 ''웰컴 투 더 정글''에서 시작해서 ''스위트 차일드 오 마인''로 끝나는 나름 매우 인간적인 빈틈많은 
웃긴 신들의 이야기.',
'상냥이',
TO_DATE('07-18-2022 20:30','MM-DD-YYYY HH24:MI'),
35,
4,
'11'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'마블 광팬인 내가 제일 좋아하는 히어로는 토르!!!! 거기다 마이티 토르까지~~!! 토르는 1때부터 영상미가 화려해서 넘좋음~~!!!',
'휴먼 사용자',
TO_DATE('07-15-2022 20:12','MM-DD-YYYY HH24:MI'),
33,
4,
'11'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'북유럽의 신으로 불리우는 토르의 망치를 사용하여 세계를 구하는 한 남자의 인생 역전!  번개 망치의 힘을 사용한 세계 구하기!',
'휴먼 사용자',
TO_DATE('04-24-2022 00:04','MM-DD-YYYY HH24:MI'),
33,
6,
'11'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'\( ˙▿˙ )/ 뉴트로 팝음악 맛집이네요 ㅋㅋㅋㅋ 70년대 감성 낭낭한 ost에 귀가 즐겁고, 귀여운 미니언즈로 눈까지 호강했습니다💛',
'소리벗고팬티질러',
TO_DATE('07-20-2022 10:29','MM-DD-YYYY HH24:MI'),
22,
4,
'12'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
7,
'미니언즈 시리즈의 특징인 ‘귀여움’을 그저 즐기기만 하면 된다. 소년 악당 그루의 이야기도 나쁘지 않지만, 
전체적인 설정의 매력이 전작과 비교해 평이하다는 느낌이 든다. 뭐, 그냥 미니언즈 보고 있으면 되니 무슨 
상관일까마는.',
'밍큐스',
TO_DATE('07-26-2022 15:52','MM-DD-YYYY HH24:MI'),
21,
3,
'12'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'작고 소중한 우리 뽀시래기 밥!ㅠ 여전히 너무 귀여워ㅠㅠㅠ진짜 미니언 하나만 저희 집으로 보내주세요ㅠㅠ 
1편보다 스토리도 액션도 재미도 더 재밌어짐! 3편도 기대할게요~~',
'citrus',
TO_DATE('07-20-2022 12:44','MM-DD-YYYY HH24:MI'),
22,
5,
'12'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'영상미 액션 스토리 저는 다 좋았습니다. 매력적인 빌런과 와칸다의 혼란속에서의 결합. 그리고 여왕인 라몬다역의 
안젤라 바셋배우의 연기는 정말 박수가 절로 나왔습니다. 처음 등장씬은 지금도 잊을수가 없네요. 기회가 된다면 또 
보고 싶습니다.',
'ekthf331',
TO_DATE('11-18-2022 10:14','MM-DD-YYYY HH24:MI'),
36,
8,
'13'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
9,
'새로운면이 많이나와서 좋았고  2편은 좀의미가있는거같이 생각이됨   앞으로 3편도 나왔으면 좋겠음  예전의 
마블영화하고는 다른면이 많아서 좋은거같음',
'장미선',
TO_DATE('11-12-2022 16:58','MM-DD-YYYY HH24:MI'),
33,
6,
'13'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'완전 호호극호!! 네이머가 어떻게 나올지 너무 궁금했는데 생각한 것보다 더 멋있었ㅠㅠㅠ 역시 마블은 마블!',
'다우니',
TO_DATE('11-10-2022 13:44','MM-DD-YYYY HH24:MI'),
33,
7,
'13'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
5,
'배우가 중요한게 아니라 시나리오가 좋아야 한다.',
'우와',
TO_DATE('08-03-2022 16:45','MM-DD-YYYY HH24:MI'),
247,
53,
'14'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
4,
'아니야...이건 아니야....증말로 아니야....
비싼 배우들 모아놓고 .....',
'hierophany',
TO_DATE('08-03-2022 17:16','MM-DD-YYYY HH24:MI'),
191,
61,
'14'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
1,
'재난 영화인줄 알았는데 영화가 재난',
'JS',
TO_DATE('08-05-2022 16:31','MM-DD-YYYY HH24:MI'),
135,
32,
'14'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
7,
'난 더이상 영웅 영화에 재미를 못 느끼는 나이가 되었나봐......

스파이더맨 뭐 다 보고 그래서 깨알같은 드립에 웃음이 나오고....

관계도 다 이해가 되면서 봤지만.....

영화 자체가 재밌다는 느낌은 안들고,,,,

과거 스파이더맨들 얼굴 보니.. " 다시 보니까 좋다 " 딱 거기까지가 내 영화평....

영웅 영화들이여... 이젠 안녕....',
'뭐뭐뭐',
TO_DATE('12-17-2021 13:24','MM-DD-YYYY HH24:MI'),
121,
46,
'15'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'앤드게임이 10년 마블 케릭터 대장정의 마침표였다면,
이건 20년 스파이더맨 시리즈의 완벽한 마침표.',
'다음얘들도쓰레기야',
TO_DATE('12-16-2021 00:34','MM-DD-YYYY HH24:MI'),
88,
33,
'15'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'등장 인물만으로도 압도적이다.

건물에서 떨어지는 MJ를 스파이더맨이 구출하는 장 면이 인상적이네...
MJ가 왜 우냐고 스파이더맨에게 묻는데  스파이더맨은 눈물만 흘리네',
'크크크',
TO_DATE('12-15-2021 15:50','MM-DD-YYYY HH24:MI'),
81,
31,
'15'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'방금 용산Ipark에서 시사회  보고 집에 가는 중입니다.
말도 안되는 설정이다. 생긱하고 편한  마음으로 보게된 영화인데 시종일관 웃게 해주는 힐링영화라는  생각이네요!! 
알찬구성에 참 재미진 영화입니다.ㅎㅎㅎ',
'쏘모즈앤',
TO_DATE('08-16-2022 22:21','MM-DD-YYYY HH24:MI'),
72,
22,
'16'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
9,
'부모님과 함께  볼 수 있는 코미디 영화를 기다리고 있었는데..
진심 처음부터 끝까지 웃으며 재밌게 봤습니다.
예고편이 재밌어서.. 예고편이 다면 어쩌나 싶어 큰 기대를 안했는데.. 
설정과 소재, 대사도 좋고, 배우들 표정연기가 아주ㅋㅋㅋ',
'빡선',
TO_DATE('08-25-2022 22:02','MM-DD-YYYY HH24:MI'),
61,
17,
'16'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'로또랑 군인이라니 이게 무슨 조합인가 싶었는데 대박 재밌음👍👍 웃다가 웃다가 웃다가 끝나는데 또 재밌기까지 
해 좋은 여름의 마무리였다',
'YS',
TO_DATE('08-25-2022 10:14','MM-DD-YYYY HH24:MI'),
58,
14,
'16'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
6,
'아 .... 나만 그런가 ㅠㅠㅠ

탕웨이 한국어 대사가 뭐라 하는 건지 도통 못 알아 듣겠네 ㅠㅠㅠ  

자막 처리 해주면 좋을련만',
'BLUESBREAKER',
TO_DATE('07-04-2022 10:02','MM-DD-YYYY HH24:MI'),
239,
73,
'17'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
5,
'영화 보는 내내 전체적인 스토리가 연결이 안될만큼 단편적이더군요.
두번이상 봐야 스토리를 이해할 수 있다면, 이는 관객에 대한 예의가 아닙니다.

두남녀가 사랑을 시작하는 개연성도 좀 떨어지다 보니, 헤어질 결심도 그 이유가 떨어졌다고 봅니다.

그리고 탕웨이의 한국어 발음이 완벽하지 않은것은 어쩔수 없다고 하더라도, 발음의 부정확으로 무슨말을 전하려는건지 캐치가 안된 대사도 있었는데,, 이 부분은 자막처리를 했으면 어땟을까 생각합니다.

한국어라고 다 들리는것은 아닙니다.',
'노란햇살',
TO_DATE('07-04-2022 09:40','MM-DD-YYYY HH24:MI'),
269,
117,
'17'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
9,
'사랑이라 명명하지 못한 당신의 고백이 자신을 붕괴시키게 할 순 없었어요. 그래서 나는 그 사랑의 진심을 다시는 
의심할 수 없도록 스스로 허물어져 무너져 기억의 바닷속 깊숙이 침잠하기로 했어요. 마침내!',
'지수',
TO_DATE('07-02-2022 21:46','MM-DD-YYYY HH24:MI'),
244,
95,
'17'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
3,
'심각하더라.. 중간에 2번 정도 졸았음. 저 많은 톱배우들을 이렇게 무의미하게 소비시키다니.. 최동훈 감독에겐 
300억이 넘는 제작비가 아니라.. 진심어린 ''고언''을 해줄 사람이 필요했던 것 같다.',
'berningrave',
TO_DATE('07-19-2022 18:36','MM-DD-YYYY HH24:MI'),
236,
104,
'18'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
5,
'뭔가 잔뜩 보여주고 싶은 욕심에 비해 뒤떨어지는 시나리오. 음향은 계속 왕왕 울려대고, 꽤나 돈 들였을 CG는 뭔가 계속 아쉽고. 간만에 대작이면서 망작이네요.

손분 넘기기 힘들듯. 제가 투자금 회수에 일조했넹.',
'bigeyez',
TO_DATE('07-20-2022 19:10','MM-DD-YYYY HH24:MI'),
187,
63,
'18'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
2,
'개연성 없는건 장르 특성상 그럴수 있다고 치더라도 영화 내내 웃기려고 애쓰는데 진짜 하나도 안웃기고 후반부 
갈수록 쌍팔년도 영화인지 착각될 정도의 식상한 감성팔이, 의미도없고 화려하지도 않은 액션씬 등 정말 수준낮은 영화',
'tamas',
TO_DATE('07-21-2022 15:28','MM-DD-YYYY HH24:MI'),
194,
73,
'18'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'단 한번이라도 직접 정성화 출현 뮤지컬을 본 사람이라면.... 그의 노력과 열정을 모른다면...
논하지마라... 영웅= 정성화다 완벽한 캐스팅이며
분명 역사에 남을 작품이 될것이다',
'윤경철',
TO_DATE('05-06-2020 09:24','MM-DD-YYYY HH24:MI'),
677,
65,
'19'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'정성화는 개그맨 출신이지만..
크고작은 영화에서 조연으로 출연하며 자기만의 연기세계를 확실히 구축한..
배우 입니다..
어설픈 아이돌출신 어색한 연기 보이는 누구보다 쨉도 안되는 연기력을 보여주는 배우입니다..
정성화 까지 마세요..
그정도 연기를 보여주기까지 엄청난 노력을 한게 보이는 배우입니다..',
'인랑',
TO_DATE('04-09-2020 01:25','MM-DD-YYYY HH24:MI'),
596,
65,
'19'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'대한 독립 만세 !! 안중근님 정말 존경스러워요',
'지후',
TO_DATE('12-04-2020 12:31','MM-DD-YYYY HH24:MI'),
339,
11,
'19'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
2,
'미안하지만 망작의 냄새가 난다',
'Redcrow',
TO_DATE('12-29-2021 20:45','MM-DD-YYYY HH24:MI'),
173,
72,
'20'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
1,
'정말 너무 완성도 떨어지고 유치하고 오글거리고  배우들 연기 못하고 스토리 진행이 매끄럽지 않다. 보다 나가는 
사람들 6명 있었고 나도 애들만 아니면 나가고 싶었다.2시간이 4시간 같이 느껴짐',
'breathe',
TO_DATE('02-01-2022 21:24','MM-DD-YYYY HH24:MI'),
35,
3,
'20'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
1,
'평점이 낮은 이유가 있었네요.',
'팥팥팥',
TO_DATE('02-04-2022 03:34','MM-DD-YYYY HH24:MI'),
32,
3,
'20'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
2,
'솔찍히 말할께...보지마라....재미없다....
극장에서 보고 후회한 첫번째 영화다.',
'관심',
TO_DATE('06-09-2022 06:59','MM-DD-YYYY HH24:MI'),
203,
49,
'21'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
2,
'지금  보고 옴. 스토리 산으로 감. 감동 없음. 개실망!!!
일본스러운 영화네요',
'nananim',
TO_DATE('06-09-2022 00:32','MM-DD-YYYY HH24:MI'),
185,
36,
'21'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
3,
'자다가 나왔습니다. 답답합니다. 중간에 나가는 사람도 많았네요.
피곤한데 집에서 잠이나 잘 걸...,',
'G-H Bae',
TO_DATE('06-10-2022 15:36','MM-DD-YYYY HH24:MI'),
150,
29,
'21'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
8,
'개인적으로 전편보다 3번째 이번 영화가 가장 만족스런 내용이네요.
중간에 살짝 졸리긴 했지만....ㅎㅎ

"악한 시대엔 악한 자가 우두머리가 된다" - 슬픈 현실이네요.',
'동방의파우스트',
TO_DATE('04-14-2022 12:45','MM-DD-YYYY HH24:MI'),
19,
9,
'22'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
1,
'0점 못주는게 너무 아쉽네요. 아니 왜 이런 캐릭터와 배우를 두고 극본이랑 연출은 이따군가요....해리포터도 충분히 
확장가능한 세계관인줄알았는데... 너무합니다진짜 이렇게 시리즈마무리하지마요 ㅡㅡ',
'이지혜',
TO_DATE('04-24-2022 08:39','MM-DD-YYYY HH24:MI'),
13,
4,
'22'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
5,
'그냥 정으로 보는 거지 뭐. 매력덩어리 Mr. 코왈스키~',
'요사리안',
TO_DATE('05-26-2022 23:53','MM-DD-YYYY HH24:MI'),
6,
0,
'22'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'어제 시사회 영화보고 내내 울었음. 너무 많은 부분 공감했고. 어느부분이 울어야하는지를 몰랐지만 계속 울고 있었음. 50대의 공감이었고. 10대의 시간을 지난 20대의 공감이었음. 
50대 부부가 꼭 봤으면. 극 추천. 우리애들이 영화속에 우리아빠 등장한 줄 알고 깜놀람. 엄마의 시간을 많이 해준 딸들이 고마웠음. 너무 자연스럽게 우리의 이야기를 해준 배우들에게 감사한다느이야기 꼭해 주고 싶음. 태어나서 
영화평 처음 함. 어제 영화보고 모처럼 행복했음.',
'여기지금',
TO_DATE('09-18-2022 13:08','MM-DD-YYYY HH24:MI'),
141,
21,
'23'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'이거   유치할까봐서 안보겠단 사람... 안보면 손해일 듯.. 이런 영화일 수록 극장판으로 봐줘야함..나는 
라라랜드보다 훨~~재밌었음.아는 노래라 그럴수 있었겠지만 암튼...탑건 담으로 평점 높을 올해의 영화임',
'BEST',
TO_DATE('09-29-2022 22:30','MM-DD-YYYY HH24:MI'),
97,
17,
'23'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'뮤지컬 영화라니 그리고 누구나 흥얼거려지는 대중가요로 만들어진 영화라니 코로나 시국이지만 꼭 영화관에서 
사람들과 어울려 같이 보고 노래도 부르고 싶어지네요..최고의 인생 영화가 될 듯 합니다.',
'dubai lee',
TO_DATE('09-30-2020 13:43','MM-DD-YYYY HH24:MI'),
67,
12,
'23'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
6,
'오늘 봤는데, 액션도 약하고 시간이 좀 길게 느껴졌습니다...굳이 3시간 정도나 할 것인지 의문이네요..
액션을 기대한다면 좀 실망하실거고, 다른 느낌의 배트맨을 보시려면 괜찮을 듯요~제 취향은 역시 크리스찬 배일의 배트맨 다크나이트!!',
'블루스카이',
TO_DATE('03-01-2022 22:19','MM-DD-YYYY HH24:MI'),
45,
16,
'24'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
1,
'가장 볼만하고 화려한 액션이라 볼 수 있는 차량 추격씬에서 그 난리를 내놓고 얻은거라곤 철자 하나틀린 단어뿐 
그마저도 중요한 단서도 아니며 추리영화 같이 수많은 단서들이 나오기에 유심히 봤으나 복선은 하나도 없었으며 
누구와 대화 하고 있는지 알수없는 연결 안되는 대사들이  배트맨의 향수를 느끼고 싶었던 기대를 
꺾어버리고  세시간내내 곤욕이었다',
'성공연구소',
TO_DATE('03-01-2022 22:34','MM-DD-YYYY HH24:MI'),
62,
39,
'24'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
9,
'그냥 죽이거나 시원하게 때리지 굳이 왜 탐정물처럼 내보내냐는 사람들은 그냥 배트맨 하나도 모르는 거임... 
배트맨은 불살이고, 원래 탐정 컨셉입니다. 영화는 살짝 아쉬운 감이 없잖아 있지만 잘 만들어진 평작이라 생각하여 
9점. 소수점이 있었다면 8.5점 정도 주고 싶습니다. 호불호가 엄~청 갈립니다. 흐름은 정확하게 내용을 알려주지 
않고 잔잔하면서도 난해하고 어두워서 집중하고 몰입하는 만큼 재미가 다릅니다. 그저 오락영화처럼 보기만 해도 
내용이 들어오길 바라는 분이라면 세시간 날리고 표값 아까워하실 듯 해요. 아무 생각없이 스토리만 보면 유치한 
영웅서사+약간의 추리물에서 그치겠지만, 불안정한 초보 배트맨의 ''성장서사''에 집중하여 해석한다면 영화를 
충분히 90%정도는 즐길 수 있을겁니다.',
'착취의손아귀찜',
TO_DATE('03-03-2022 09:52','MM-DD-YYYY HH24:MI'),
46,
29,
'24'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
9,
'이거 천안함 1번어뢰 얘기하는거 같은데

아무도 진실을 말하지 않는다 

다들 알고 있으면서

이거 같은데?',
'흐르는강물',
TO_DATE('01-02-2023 01:53','MM-DD-YYYY HH24:MI'),
34,
4,
'25'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
6,
'천안함에서   우리 해군이 여럿 죽었는데 살아 돌아온 해군들을 승리하고 들어온것 처럼 영웅시하고 특진시킨 얘기 꼬집는',
'조광래',
TO_DATE('12-23-2022 19:39','MM-DD-YYYY HH24:MI'),
26,
6,
'25'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
8,
'오늘 보고 왔어요. 억지 신파가 아니라 어쩔수 없는 상황에서의 선택으로 인한 남겨진 자의 고통을 고스란히 느낄수 있었어요. 아직도 먹먹하네요.',
'shopgirl2',
TO_DATE('11-17-2022 00:14','MM-DD-YYYY HH24:MI'),
37,
18,
'25'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
1,
'보러갈까 하고 고민중에 강원도지사 김진태가 너무 재밌고 거짓말을 못하는게 자기을 보는듯 하다고 해서 안가기로 맘먹음.5.18을 폭동이라고 주장하는 지만원을 초대해 ㄱ구회에서 떠들게 했던 장본인이고 개검출신에 정치는 하수였던 자가 자기을 닮았다는데 정내미가 뚝 떨어짐.라미란 연기가 궁금했는데 극장에서 내려오면 그때 공짜로 보겠음',
'캐논',
TO_DATE('09-28-2022 16:51','MM-DD-YYYY HH24:MI'),
471,
53,
'26'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
1,
'김진태가 자기 이야기라네 ㅋㅋ 걸러야지',
'슈가처럼',
TO_DATE('09-27-2022 21:23','MM-DD-YYYY HH24:MI'),
287,
40,
'26'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
2,
'강원도지사 김진태가 추천 합니다. 그래서 안봐요.',
'하루는',
TO_DATE('09-28-2022 20:38','MM-DD-YYYY HH24:MI'),
244,
34,
'26'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'와 기대안했는데 노래, 볼거리, 화려함, 스토리 진짜 흠잡을데가 없었어요. 애기랑 같이봤는데 제가 더 반했어요. 
두말없이 봐보세요 강추에요..진짜 평점쓰는건 처음이에요..ㅎ티비광고할때는 뭔가 재미없어보였는데 노래가 
진짜..꼭보세요',
'심혜경',
TO_DATE('01-11-2022 17:28','MM-DD-YYYY HH24:MI'),
16,
1,
'27'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'어제 젤 늦은시간관람 했어요. 모든 캐릭터들 귀엽고 사랑스럽고..한편의 화려한 뮤지컬공연을 본듯 합니다.
볼거리..노래들..다 좋아요. 영화관 관람 추천드려요^^',
'해피바이러스',
TO_DATE('01-07-2022 11:14','MM-DD-YYYY HH24:MI'),
13,
0,
'27'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'크리스마스의 악몽과 토이스토리 이후로 역사상 최고의 애니메이션...정말 감동 그 자체.. 평점 10점 만점에서 100점 
주고 싶다.. 정말 뮤지컬을 싫어하는 나 조차 온몸에 소름 돋으면서 봤던 영화... 이걸 영화관에서 못봤더라면 얼마나 
아쉬웠을까... 인생 애니매이션이다.... 정말 무조건 봐라....',
'하잉',
TO_DATE('01-25-2022 12:38','MM-DD-YYYY HH24:MI'),
12,
0,
'27'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'생애 처음으로 영화관에서 짱구는 못말려를 보았다. 역시 기대를 저버리지 않는 짱구였다.

어렸을 때는 짱구가 멍청하고, 버릇없고, 철없는 갱생해야 하는 아이인 줄 알았고, 학교나 사회에서는 그렇게 가르침을 받아왔는데, 어른이 되니까 내가 오히려 짱구보다 못한 사람이라는 생각이 든다.
품위와 기품이 있고, 수준이 있으며, 완벽과 엘리트주의 등 완벽을 추구하고 동경하게 하는 세상이 오히려 짱구에게 배워야 하지 않나 싶다. 앞에 언급했던 것들보다 더 중요한 것은 ''사람이 되는 것''이라는 것을 짱구가 알려주는 거 같다.

너무 재미있으면서 감동적이었으며, 개인적인 생각으로는 어른 제국의 역습 이후 최고의 영화가 아닌가 싶다.',
'엘피스',
TO_DATE('09-29-2022 22:21','MM-DD-YYYY HH24:MI'),
20,
3,
'28'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
8,
'이번에는 입시 및 교육에 대한 이야기다! 엘리트를 양성하기 위해, 서열을 매기고, 순위에 따라 차등을 두어 보상을 
제공한다면 어떨까. 짱구 일행이 펼치는 저항기!',
'미노',
TO_DATE('10-08-2022 23:27','MM-DD-YYYY HH24:MI'),
15,
3,
'28'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'아인슈타인이 프린스턴 대학교 나왔는데 프린스턴 대학교에는 대학생들이 교복입고 다녔었다. 사이버대학교는 
한술 더 떠서 집에서 추리닝입고 책상위에 다리 올려놓고 봐도 된다. 밥먹으면서 강의 들어도 된다. 초등학교도 
국민학교라는 이름이 훨씬 더 정감이 있다. 밖에서 고생하는 사람들 걱정해주는게 실제로는 그 사람들을 더 
불편하게 만든다고 한다. 나의 초인적 자유가 남들에게 전파가 되는 것 ! 짱구야 사랑해~',
'슈렉',
TO_DATE('12-04-2022 20:36','MM-DD-YYYY HH24:MI'),
11,
1,
'28'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
3,
'등장인물들의 서사가 부족해도 너무 부족하다',
'락큐',
TO_DATE('10-31-2022 11:27','MM-DD-YYYY HH24:MI'),
13,
2,
'29'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
6,
'대체로 산만하고 지루한 말장난이 심함. 배우빨로  밀어붙이는 영화.',
'salsaxxx',
TO_DATE('10-20-2022 18:21','MM-DD-YYYY HH24:MI'),
16,
7,
'29'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
6,
'디씨에 대한 의리로 봐 줌. 근데 드웨인 존슨이 히어로면 너무 사기 아닌가요? 그냥 슈퍼맨보다 더 세 보이는데...
스토리, 다른 캐릭터는  너무 구려요.ㅠ',
'살다보면',
TO_DATE('10-19-2022 19:14','MM-DD-YYYY HH24:MI'),
16,
8,
'29'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
9,
'이영화를 보구나면 국힘당이 왜 그렇데 대장동에 매달리는지 알게됩니다. 했느냐구 중요한게 아니구 그렇게 보게 만드는게 중요하다.',
'팡야',
TO_DATE('01-27-2022 03:29','MM-DD-YYYY HH24:MI'),
358,
89,
'30'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
9,
'이 영화 20대들이 좀 봤으면 좋겠네...영호남 지역구도를 만들어서 국민들끼리 싸우게 만든 게 바로 국짐당의 
전신이고 그 전통을 물려받은 국짐당과 극렬 지지층인 알베들이 지역과 소수자를 비하하는 짓거리를 하고 있다는 걸.',
'각자무치',
TO_DATE('01-29-2022 20:06','MM-DD-YYYY HH24:MI'),
312,
58,
'30'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'이간질....예전은 영호남 이간질로 50년 해먹고...요즘은 남녀간, 세대간 이간질로 덕볼려고 하는 세력이 
있다....2030과 6070이 4050을 포위한다는 세대 이간질...젠더갈등을 부추키는 남녀 이간질...언론도 이간질로 돈 벌고..에휴',
'오늘은',
TO_DATE('01-31-2022 23:09','MM-DD-YYYY HH24:MI'),
241,
17,
'30'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
5,
'대충 줄거리 보니깐 인비저블 게스트가 바로 떠오르던데 
긴가민가 하긴 한데 혹시 인비저블 게스트 리메이크작입니까??',
DEFAULT,
TO_DATE('10-18-2020 22:44','MM-DD-YYYY HH24:MI'),
95,
15,
'31'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'소지섭 김윤진 연기 티키타카 미쳤는데 중간에 나나도 절대 안 밀린다',
'성윤제',
TO_DATE('10-26-2022 11:24','MM-DD-YYYY HH24:MI'),
27,
11,
'31'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'오늘보고왔어요
추리.스릴러.심리 좋아해서
감상했어요
연기력 역시 좋고 
출연진의  강렬한 연기가 인상깊네요
추천합니다
결과는 영화관으로 가보세요
저는 추천합니다
자백! 짱',
'멍뭉이',
TO_DATE('10-27-2022 17:51','MM-DD-YYYY HH24:MI'),
24,
9,
'31'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
7,
'차세대 인디아나 존스라는 뻥은 치지 말자
뭔가 큰 임팩트 한 방이 없었엄',
'유리지아',
TO_DATE('02-19-2022 21:19','MM-DD-YYYY HH24:MI'),
10,
2,
'32'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
4,
'액션씬 빼고는 잠와서 제대로 보기 힘드내요 내용도 뜬금포..우연의 일치로 전개됨',
'님말맞',
TO_DATE('02-25-2022 22:13','MM-DD-YYYY HH24:MI'),
9,
2,
'32'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
5,
'뭘 어떻게 하려나 지켜봤더니, 왜 저렇게만 하나 싶다.',
'지수',
TO_DATE('02-21-2022 19:34','MM-DD-YYYY HH24:MI'),
9,
2,
'32'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
1,
'알바들이 커서 기레기 되는거죠?',
'휴먼 사용자',
TO_DATE('01-30-2022 12:10','MM-DD-YYYY HH24:MI'),
19,
1,
'33'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
3,
'내가1빠네....
와이프가 킹스맨보자는거 내가 끝까지우겨서 봤음.
진짜 미안함...영화는 주연만보고 고르면절대안됨.
영화는감독이 만드는거임...
뭘말할려는지..도무지!..
보다가 졸았음..',
'우지',
TO_DATE('01-08-2022 20:39','MM-DD-YYYY HH24:MI'),
27,
10,
'33'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
1,
'최우식님 내한공연 그만 하시고 캐나다 가서 돈 많이 벌고 행복하셨으면 좋겠습니다. 이땅의 청춘들은 오늘같이 추운 명절연휴에도 국방의 의무를 위해  열심히 노력하는 모습이 안쓰럽습니다.',
'꽃상훈',
TO_DATE('01-30-2022 17:33','MM-DD-YYYY HH24:MI'),
35,
19,
'33'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'내용보고 울고,
커플사이에 남자둘이서 이거보러온
현실에 울고
두번 울었다...ㅠㅠ',
'송지한',
TO_DATE('12-03-2022 22:11','MM-DD-YYYY HH24:MI'),
42,
7,
'34'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
7,
'노을진 서울우유같은 영화… 다음 대사를 예상할 수 있으나 그래도 눈물이 좔좔 흘렀네요.',
'정민주',
TO_DATE('02-14-2023 16:49','MM-DD-YYYY HH24:MI'),
18,
1,
'34'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
8,
'남주, 여주, 친구 역할을 한 조연까지 연기는 자연스럽게 잘 한 것 같아서 괜찮음. 영상의 색감과 연출도 좋음. 
비주얼도 좋음. 하지만, 스토리가 너무 예상하기 쉽다. 여운이 남는다는 것이 장점이지만(막 눈물 쏟고 오열할 
정도의 슬픔이 있지는 않지만, 찝찝하게 오래가는 여운이 있음), 동시에 자연스럽지 않고 기존 일본 멜로 영화의 
클리셰로 인한 인위적인 것임에 아쉬움이 남는다. ''일본식 신파가 이런 것인가?'' 라는 생각을 했음. 영화를 보고 
느낀점은 남녀 주인공 보다 친구 역할로 나오는 이즈미의 입장에서 영화를 보는게 더 재미있게 즐길 수 있을 것 같다는 것.',
'승하민',
TO_DATE('02-04-2023 14:06','MM-DD-YYYY HH24:MI'),
16,
0,
'34'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'해적 도깨비 깃발 같은 쓰레기 영화 보다 백배 나음',
'태화성',
TO_DATE('02-17-2022 11:54','MM-DD-YYYY HH24:MI'),
13,
8,
'35'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
7,
'보는 내내 몰입과 공감 대신 유치하고 오글거려서 즐기지 못하는 게 나이 때문인 것 같아 10년만 젊었으면 좋겠다는 생각을 문득했다. 액션은 좋았다.',
'오늘',
TO_DATE('02-27-2022 21:58','MM-DD-YYYY HH24:MI'),
5,
1,
'35'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
7,
'TVA 1,2기 너무 재미있게 보고  코믹스도  현재까지  다 봐서 기대를     
 많이 했는데  좀 실망이다.  중반까지 1시간이 꽤 지루해서  4DX인데도  보면서 살짝 졸았다.',
'Education',
TO_DATE('02-23-2022 22:07','MM-DD-YYYY HH24:MI'),
5,
1,
'35'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
2,
'감독은 더이상 영화 안만드는게 시대에 30년  뒤처진 감성',
'영화는 역시 토렌트',
TO_DATE('10-29-2022 20:07','MM-DD-YYYY HH24:MI'),
308,
122,
'36'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
1,
'이건 머!
1점도 아갑다!
돈 좀 벌었으니 본국으로 돌아가야지!',
'행복',
TO_DATE('12-01-2022 13:29','MM-DD-YYYY HH24:MI'),
32,
2,
'36'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
2,
'동석 형 ㅡ 정말 이건 배신이다
최악 입니다
절대 관람 비추 입니다
중간에 나왔어요 시간 아까워서 ㅜㅜ',
'뿌시뿌시',
TO_DATE('11-30-2022 22:31','MM-DD-YYYY HH24:MI'),
32,
4,
'36'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
1,
'이번건 그닥인듯 전 잤어요 애들도 그닥
사은품 때문에 두번 보려고 했는데;;;
그냥 안보기로;',
'버럭',
TO_DATE('06-08-2022 13:25','MM-DD-YYYY HH24:MI'),
1,
0,
'37'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'전설의 몬스터로 부터 세상을 구하기 위해서 싸우는 지우 일행! 그들 앞에 나타난  로켓단 일당!',
'휴먼 사용자',
TO_DATE('05-02-2022 10:45','MM-DD-YYYY HH24:MI'),
1,
0,
'37'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
7,
'.',
'강민호',
TO_DATE('07-29-2018 23:39','MM-DD-YYYY HH24:MI'),
1,
0,
'37'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'중1 아들과 보고 왔음.
다 보고나서 우리 아들 "엄마 너무 좋은 영화다!" 너무 재미있었다고
몇번이나 말하네요.
같이 차 마시면서 영화내용 이야기도 하면서 우리 함께 즐겁게 본 영화에요.
적극 추천합니다.',
'봄날',
TO_DATE('03-09-2022 18:09','MM-DD-YYYY HH24:MI'),
56,
6,
'38'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'잔잔하고 감동있는 좋은 영화입니다. 중간중간 명대사가 나오네요. 
"틀린 문제에서는 옳은 답이 나올수가 없다" 
"머리좋은거, 노력하는거보다 중요한 건 용기, 오늘 안 풀리면 다시 내일 해보겠다는 마음"',
'빨간콩',
TO_DATE('03-13-2022 20:15','MM-DD-YYYY HH24:MI'),
51,
2,
'38'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'수학전공자여서 인지..
그냥 별멘트 아닌데도 자꾸 눈물이  나더라구요^^
따뜻합니다',
'엘이제이',
TO_DATE('03-12-2022 16:54','MM-DD-YYYY HH24:MI'),
44,
2,
'38'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'진짜 경악하며 봤습니다.. 지금까지 본 코난 극장판 중 탑3 안에 들 정도로 재미있었습니다...',
'재현',
TO_DATE('07-17-2022 11:44','MM-DD-YYYY HH24:MI'),
5,
1,
'39'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'엄청 재미있어요!!!!',
'cjstk',
TO_DATE('07-15-2022 20:56','MM-DD-YYYY HH24:MI'),
5,
1,
'39'
);
INSERT INTO tblreview(reviewseq, reviewrate, reviewcontent, id, postdate, good, bad, seq) 
VALUES 
(
reviewseq.nextval,
10,
'경찰학교 스토리 + 로맨스 스토리 + 코난다운 미스터리 + 반전
이 네가지를 한번에 다 넣어서 이런 수작을 만들수 있는게 코난 말고 뭐가 있을까',
'길위의 독수리',
TO_DATE('07-17-2022 19:02','MM-DD-YYYY HH24:MI'),
4,
2,
'39'
);


--50
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 7.0 , 
	'마지막에 희수가 했던 말이 가장 인상이 깊네요
세상은 멋있자가 이기는 것이 아니라 ♪♪♪놈이 이긴다고
오늘 윤석열의 취임식을 보면서 이 말이 정말 맞구나 생각되네요
그가 문재인을 배신할때 정치검찰 할때 조국을 수사할때
나라에 엄청난 파동을 몰고올때 아무도 그의 정확한 의도를 몰랐다', '새벽노을',DEFAULT, 52, 17, '50');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 1.0 ,
	'깡패영화는 이제 그만~!', '새벽노을',DEFAULT, 26, 4, '50');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 1.0 ,
	'생략  생략  생략...
영화 서사의 핵심 중 하나인 인물 간의 관계 하나
 관객에게  이해시키지 못하는 엉성하고
시건방진  아마추어 연출...

감성 누아르?? 웃기는 소리는 금물.
영화 전체가 상투적인 클리셰 덩어리.
건달의 내면??? 헛소리도 금물.
깡패 양아치들에게 고뇌를 덧씌운
 소설가의 똥폼 수작질.', '감찬',DEFAULT, 36, 17, '50');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 1.0 ,
	'이런 저질 양아치 영화 그만 제작혀라.
갱상도넘들은 조폭도 미화하는 더러븐 나라여~', '동방의 파우스트',DEFAULT, 50, 33, '50');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 1.0 ,
	'느와르 란 단어 함부로 쓰지 말자. 그냥 글 쓰는 사람이 늦게 욕심 내서 만든 감독 데뷔 80-90년대 식 구닥다리 깡패 영화다.', '저녀석',DEFAULT, 43, 26, '50');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 1.0 ,
	'개쑤러기영화
절대 관람금지', '일장춘몽',DEFAULT, 23, 7, '50');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 1.0 ,
	'멀리 범죄와의 전쟁, 신세계(뭐 이건 리멕이니), 
가까이 범죄도시... 이런 맛을 본 관객이 보기엔 너무 밋밋하지 않나싶다.
더군다나 갱들의 이야기에서 얻을 수 있는 것따위는 존재할 리 없으니...
정우 배우 연기력이 아깝더라는...', '2-10-0',DEFAULT, 21, 5, '50');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 10.0 ,
	'보고 싶었던 작품인데 하도 여기서 개연성 악플이 많아서 버티다가 디오리지널로 vod관람함
결론은 한시즌짜리라도 현재 배우들 그대로 드라마로 만들면 느와르 드라마 수작이 될 작품임
이런 건달 에픽일대기를 2시간에 욱여넣느라 디오리지널 기준으로도 좀 터져나온 부분이 있긴함
그러나 모두 감안해도 배우들 연기는 2020 이후로 최고라고 생각되고 분명 잘 만든 느와르인건 분명함
확실한건 강릉 따위랑 비교불가이고 개인적으로 8점 주고 싶은데 테러충들 보기싫어서 만점 줌ㅋㅋㅋ', 'oio',DEFAULT, 21, 7, '50');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 1.0 ,
	'졸다가 자다가 나옴....핵노잼...', '별빛바램',DEFAULT, 21, 8, '50');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 4.0 ,
	'정우 연기는 tv드라마 연기 같음', 'minmaster',DEFAULT, 20, 7, '50');	



INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 10.0 ,
	'늑대 왜케 섹시함ㅋㅋㅋ 조카랑 보러 갔다가 내적 흥 오지게 채우고 갑니다^ㅡ^ 드리웍스ver. 케이퍼물 최고시다..', 'wodnls1',DEFAULT, 11, 2, '49');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 8.0 ,
	'드림웍스 애니 답게 발랄하고 유쾌하다. 아이들 수준의 스토리텔링을 성인도 부담없이 즐길 수 있게 만드는 출중한 능력. 항상 다음 작품을 기대하게 만든다.', '밍큐스',DEFAULT, 11, 3, '49');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 8.0 ,
	'어른과 아이들 모두 재밌게 볼수있는 가족영화네요. 어른들은 뻔한 내용이겠지만 아이들 기준으로는 충분히 재밌게 볼만한 영화입니다. 아이들 영화는 역시 악당이 있어야 재밌어 하네요.^^', '흰둥이',DEFAULT, 11, 3, '49');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 10.0 ,
	'유쾌하네요~ 아이들 보여주러 같이 관람하러 갔다 재미있게 잘 봤습니다. 너무 어린 아이들에게는 좀 어려울 도 있겠다는', '망니',DEFAULT, 10, 2, '49');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 10.0 ,
	'트름웍스최초 범죄오락물이라 청소년어린이관람불가 인줄알았더니 전체관람가였어 ㅋㅋㅋㅋㅋㅋ 온가족이볼수있는 최초범죄만화 ?ㅋㅋㅋ', '최진호',DEFAULT, 10, 2, '49');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 7.0 ,
	'예상에서 크게 벗어나지 않는 뻔한 이야기를 보여주지만, 개성 있는 캐릭터들과 유쾌한 분위기가 즐거움을 선사한다. 속편이 나와도 좋을 듯.', '오늘',DEFAULT, 9, 1, '49');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 10.0 ,
	'캐릭터는 주토피아 재질에 개성도 강하고.. 액션 시퀀스도 애니에선 처음 보는 느낌인듯?? 재밌었음!', '동동',DEFAULT, 10, 3, '49');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 10.0 ,
	'디즈니가 못하는걸 해낼때의 드림웍스와 2D애니에 경의를 표출하는 감독의 연출', '트레이든',DEFAULT, 9, 3, '49');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 9.0 ,
	'사운드 뮤직 들이  조아서  신나고 각  케릭터들의  표정 들이  마치
실제 같이  살아 숨 쉬는 듯 하내요', '바크',DEFAULT, 8, 2, '49');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 10.0 ,
	'액션도 좋고 어른들이 봐도 재밌음ㅋㅋㅋ', 'hello',DEFAULT, 8, 2, '49');	


INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 10.0 ,
	'킹스맨 폼 다시 찾앗네 진짜 개존잼이엇음.. 이렇게 된 이상 시리즈 쭉 가보자고', 'wldir00dw',DEFAULT, 19, 8, '48');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 8.0 ,
	'기존 킹스맨 1,2편의 B급 감성으로 극장에 들어갔다면 다소 당황될 수도 있음.

어찌 보면, 웃음기나 그 유명했던 머리(?) 폭죽 같은 황당한 영상이 나오는 것도 아니다.

차라리,최근에 전쟁영화였던 헥소고지나 1917도 다소 생각나기도 했음.

처음에 다소 지루할 수 있는데 그 이유는 세계1차 대전의 발발 사전 지식이 없으면 뭐지? 할 수 있다.

아마도, 실제 사실에 킹스맨의 탄생 비화를 교묘하게 집어 넣은 것이라고 보면 될 듯 하다.

중반 이후로는 깔끔한 액션이나 전개로 재미도를 갖게 한다.

혹시라도 쿠키영상이나 그런데서 해리나 에그시의 등장을 기대했는데 그러진 않았다.

즉, 킹스맨의 이름을 딴 기존 것과 다른 시대와 감성의 다른 영화라 평할 만 하다.', 'Freeman',DEFAULT, 17, 6, '48');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 8.0 ,
	'킹스맨의 탄생..
실제 역사를 재미나게 각색했다', '코스모스',DEFAULT, 15, 4, '48');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 8.0 ,
	'가장  모범적인 프랜차이즈 아닐까 박수 칠수록 더 좋아지는 킹스맨', 'switch',DEFAULT, 11, 3, '48');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 8.0 ,
	'1.2편과 달라서 살짝 당황했지만  넘 잼났슴  내용도 훨좋고', 'kaory',DEFAULT, 12, 5, '48');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 8.0 ,
	'역동적 비쥬얼이 주류인데, 사제 라스푸틴의 현란한 댄싱 액션이 돋보인다.^^  침공에 대한 반격을 묘사한 피날레 차이콥스키의
'' 1812  서곡'' 으로 ~  귀 호강도 만끽한다 !!  (쿠키1)', '즐산',DEFAULT, 9, 2, '48');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 10.0 ,
	'킹스맨의 설립된 개기를 역사적 사실에 대입하여 만들어진 걸작! 개인적으로 굉장히  잼있게 봤음.👍', '무한의주인',DEFAULT, 12, 6, '48');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 8.0 ,
	'재미있게 본 영화..시대상황에..맞는 실존인물들...라스푸틴과 싸움이  코믹한 연출이어서 많이 웃음..짧은 장면 조차도 디테일한 연출이 꽤나 많은 고민과 신경을쓴 영화...재미로 보기엔 딱인 영화', '하얀잠수함',DEFAULT, 9, 3, '48');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 10.0 ,
	'1차대전 배경, 메세지, 날액션 넘넘 좋음
랄프 아저씨도 해리슨 포드 닮은 멋진 배우!!!', '화이링',DEFAULT, 8, 2, '48');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 10.0 ,
	'아들이 부상병을 들쳐 업고 포탄과 기관총 속을 뛰는데 손에 땀이 나는듯 겨우 살아서 한숨을 쉬는데 갑자기 어흑 눈물이 주륵 양차대전을 모두 처음부터 끝까지 승리로 이끈 영국이 배경인 거대한 스케일의 영화 멋있다 절벽에서의 액션도 끝내주고 요근래 본 영화 중킹스맨 최고 ! ㅎㅎ', '풍성한열매',DEFAULT, 7, 1, '48');	


INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 10.0 ,
	'반대 누른 사람들은 친일파 후손들이야?', '도베르만',DEFAULT, 301, 36, '47');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 10.0 ,
	'이건 무조건 봐야지 이런 영화는 
대한민국에서 떵떵거리면서 사는
친일 매국노 자손들이 조금이라도 반성하는 계기가 되었으면 한다 ..', 'soccerboy',DEFAULT, 252, 24, '47');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 10.0 ,
	'아직도 친일 프레임속에 산다고, 지금이 어느시대인데 이런영화를 만드냐고, 또 반일이냐고 하는 사람들은 한국사를 다시 배우는건 어떨까요
한국사 인강 이비에스에서 무료로 들을수 있습니다
자신의 행동이 역사에 어떻게 기록될지 생각하며 사셨으면 좋겠습니다
독립운동가들의 간절한 꿈이었던 대한민국에 우리가 살고 있습니다
10월 26일은 안중근 의사 의거일입니다.', '유유',DEFAULT, 229, 12, '47');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 10.0 ,
	'강점기시절 앞잡이핏줄들이 얼마나 불쾌해할까?
우리는 살기 위해 일제에 부역한 것이다란 논리는 일단
저어기 독일이 어떻게 해왔는지 잘 보면 알테고
강점기엔 일본에 들러붙고
이후엔 미국에 들러붙어 늘 호위 호식 하면서 잘 살고 있지
문화로라도 엿 좀 먹어라 이게 바로 k-movie!!
추천 도서로는 뉴스타파사의 친일과 망각도 추천합니다!!', 'Legendssancho',DEFAULT, 219, 18, '47');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 10.0 ,
	'10월26일은 다카키 마사오 처형날', '보이스피싱척살',DEFAULT, 201, 20, '47');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 10.0 ,
	'10.26 개봉에 왠지 노리신것같아요ㅋㅋ친일파 척결', '인셀덤정일령',DEFAULT, 154, 6, '47');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 10.0 ,
	'우리나라엔 아직도 친일매국노들이 상상이상으로 많이 남아있다...
현 정부도, 정치인들 조차 친일매국짓을 하고있다...
전범기를 펄럭이며 한미일동맹이란 미명아래 동해에서 독도 연안에서 훈련을 했다...
정말 더러운 잔재들이다...', '잘살아보세',DEFAULT, 137, 6, '47');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 10.0 ,
	'미리 별 10개 쾅', '효지니',DEFAULT, 127, 14, '47');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 10.0 ,
	'대한독립 만세!!', 'PPK',DEFAULT, 123, 12, '47');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 10.0 ,
	'와 기대 되는 영화입니다.', '백두산2025',DEFAULT, 104, 8, '47');	


INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 5.0 ,
	'차라리 영화 속에 나오는 침팬지 이야기를 영화 한 편으로 만들면 더 재밌을듯', '종철',DEFAULT, 33, 10, '46');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 2.0 ,
	'지금 보고왔다 보지마라 욕나온다.  뭔가 의미를 준다고 애쓴거 같은데 공감도 안되고 지루하고..배우들간 대사도 연계성이 없고 유치하다는 생각밖에는 안든다.', '독행',DEFAULT, 32, 9, '46');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 5.0 ,
	'영화 자체가 좋아서 해석하는 게 아니라 해석하기 위해 영화를 보는 것 같음 전체적으로는 별로...', '으잉',DEFAULT, 32, 11, '46');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 5.0 ,
	'개봉일 관람했는데 생각보다 실망
솔직히 지루해서 하품 여러번 했음
그 괴물의 정체가 뭔지 보고도 모르겠음.', '버드나무류',DEFAULT, 29, 13, '46');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 1.0 ,
	'내가진짜 조던필 팬이라서 혹평 안믿고 봤는데 이정도로 곱창낼줄은몰랐다', 'NUGS',DEFAULT, 22, 7, '46');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 2.0 ,
	'방금 보고 나옴 
대체 먼 내용인지 모르겠음 
하늘에  떠다니는 현수막 귀신 정체도 모르겠고 
안보는게  나을듯', '영호',DEFAULT, 22, 7, '46');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 2.0 ,
	'관객들에게 너무 많은 것 복선 깔아 알려주려는 영화는 싫타,,, 이게 무슨 내용인지? 처음에는 구름속에서 빠르게 날아다니는 원반형 UFO를 보여주더니,, 나중에는 이게 생물체라 사람들을 빨아들여 잡아먹는데... 이런 자유자재로 날아다니는 생명체에 도전하여 헤체시키니,, 천이 길게 늘어져 날아다니고,,무슨 헤파리를 연상시키게 만드는건지? 그걸 공기주입 인형을 삼키게해 완전 분해시키네... 대체 뭘 보여주려고 이런 내용을,,, 흥미-⟩공포-⟩허탈,,,  재미있다는 사람은 그 속에 무슨 의미를 알고 재미있다고 하는 건지??  시간 아깝고 돈 아깝고,,, 처음기대 9,,재미2', '존트럭불타',DEFAULT, 32, 20, '46');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 5.0 ,
	'기대가 너무 컸나. .
조던필의 이런 스타일을 원한건 아닌데...', 'lemmy',DEFAULT, 23, 12, '46');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 2.0 ,
	'영화의 두가지 재미  또는 감동
모두 최하입니다
계속 드는 생각이 저 상황이  왜??
왜 이런 걸까 
왜 이런 상황을 연출한 것일까
보지마시길 바랍니다', '이건희',DEFAULT, 21, 10, '46');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 1.0 ,
	'올 해 최악의 영화 
조던 필 거품이 벗겨진것 같네요.', '블리트',DEFAULT, 22, 12, '46');	


INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 8.0 ,
	'문소리 배우님의 연기가 몰입이 안되었어요.
저만 그런가했더니 동행한 동료도.
배우 스스로 역할에 충분히 못빠진듯.', 'sum',DEFAULT, 36, 12, '45');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 10.0 ,
	'벌레충들이 자라서 유가족앞에 피자 먹방한다', DEFAULT,DEFAULT, 21, default, '45');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 7.0 ,
	'괴물 같은 자식을 낳은 건 악마같은 부모였네요.
학교 폭력을 웃으면서 저지르는 자식들의 악마같은 부모 얼굴도 평소에는 선한 이웃의 얼굴이라니...', '푸르뫼',DEFAULT, 21, 1, '45');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 8.0 ,
	'다들 연기 넘 잘하셨는데 , 문소리 배우만 연기하는게 넘 어색해서  나올때마다 몰입이 안됨. 옥의티 였음', '케빈',DEFAULT, 31, 14, '45');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 6.0 ,
	'문소리는 연기한지 오래되었는데...영 어색하고  어울리지않더군요', '사냥꾼',DEFAULT, 30, 13, '45');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 10.0 ,
	'내  자식이 피해자도 가해자도 될 수 있는 현실.
내 자식이 가해자일 수 없다는 부모의  이기심, 가해자임에도 비도덕적인  방법과 권력을 야비하게 휘두르는  인간의 추악한 면을  잘  그려낸 영화.
가슴이 먹먹하다.
제작진과  배우님들  모두  잘 하셨습니다!!!!!!!', '얼큰할멈',DEFAULT, 19, 2, '45');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 7.0 ,
	'현실은 검사까지 더해져서 더욱 추악하다', 'Excuse you',DEFAULT, 16, 1, '45');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 10.0 ,
	'부모 찬스 ... 알고 보면 태어날 때부터 시작되죠. 학교는 이런 설정을 더 공고히 합니다. 아이들은 스스로 포기하기도 하고 적당히 묻어 갑니다. 피해는 고스란히 흙수저의 몫. 실적은 고스란히 금수저의 몫. 특히 요즘 의사나 법관들을 보면 니 부모  얼굴을 안다는 말을 하고 싶을 때가 많아요. 스스로의 노력도 있었겠지만 본인의 노력만으로 안된다는 건 학교에 있어보면 알죠. 실적도 몰아주기... 😔  만든지 좀 된 작품이라는데 시의적절한 작품이네요. 작품을 고른 감독의 의식에 박수를 보냅니다.', '조나단',DEFAULT, 17, 3, '45');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 9.0 ,
	'정순신 얘기였구나', 'esisss' ,DEFAULT, 13, 0, '45');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 7.0 ,
	'언제나 부모가 문제!', '하늘호수',DEFAULT, 10, 1, '45');	


INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 10.0 ,
	'영화 재밌게 봤습니다....그런데 댓글에 이 영화 망작이라고 욕하시는 분들..취향 다른 것도 알겠고 아쉬운 것도 알겠는데 열연한 배우들 생각해서라도 과도한 욕은 삼가주세요......보신 분들이라도 지나치게 욕하면 안되고 안 보신 상태에서 물타기 하시는 분들.........그러지 마세요 제발. 이 분들도 열심히 한 겁니다. 영화라는 것이 완벽하기는 어렵습니다. 아쉬운 점이 있으면 하셔도 되는데 욕은 제발 하지 마세요........그걸 듣는 배우들은 가슴 찢어집니다..', 'Renamed',DEFAULT, 83, 44, '44');	

INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 7.0 ,
	'제목을 아줌마라고 했어도 될뻔', '붉은돼지',DEFAULT, 37, 11, '44');	

INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 8.0 ,
	'오프닝은 트랜스포터   엔딩은   레옹', '붉은돼지',DEFAULT, 29, 7, '44');	

INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 5.0 ,
	'라이언고슬링 주연의 영화 ''드라이브(2011)''와 상당히 닮았어요.  아무도 이 영화를 언급하는 사람이 없는 걸 보니 ''드라이브'' 보신 분이 별로 없으신가봐요. ''드라이브'' 꼭 보세요. 가슴 후벼파는 걸작입니다.', 'tippy',DEFAULT, 25, 8, '44');	

INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 9.0 ,
	'큰 기대안하고 봤는데 전  넘 재미있네요~~
박소담님  연기 긴장감 넘치고
송새벽님 연기 넘 잘하시네요.', '호뚜끼',DEFAULT, 26, 13, '44');	

INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 8.0 ,
	'시국이 이런상황이 아니라면  천만가능한데요  박소담 믿고 보았는데 👍 역시 최고입니다  다른배우분들도  박수드립니다  작품만든다고  모두모두 수고많으셨어요   우리 모두행복합시다', '휴면 사용자',DEFAULT, 21, 10, '44');	

INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 10.0 ,
	'박소담 짱~~~~ 재밌게 봤습니다. 굿굿', '유역비',DEFAULT, 18, 8, '44');	

INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 1.0 ,
	'개인 취향이라 다들 호불호는 있겠지만
영화보며 가장 짜증나는 것들...
1.이유없이 원인없이 너무나 잔인하게 사람을 패는것..
2.착한 사람들이 잔인하게 죽임을 당하는것..
3.어린아이가 잔인한 폭행에 노출되는것..
4.스토리가 개연성없이 진행되어 결말은 배가 산에
   가 있을때
5.감독.작가의 어눌한 실력과 어설픈 욕심이 출연 배우들만 
  죽도록 고생시켰음이 보일때..
6.출연한 배우들의 역량을 제대로 살리지 못했다 느낄때..
7.80년대 홍콩 영화를 배낀 듯함을 느낄때.
★한마디로 이 영화는 너무나 좋은 소재와
    너무나 좋은 배우들을 가지고 있었음에도  불구하고
    졸작은 이렇게 만드는것이라고 보여준 영화같음.
    막판에 엉망으로 뭉개진 그림 같음.', '기차길옆',DEFAULT, 22, 13, '44');	

INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 10.0 ,
	'진짜로 오랜만에 아이들과 영화를 보러 극장으로 가는 날~ 검은사제부터 박소담 연기를 너무 좋아해서 선택한 영화였는데 너무 짜릿했고 재미있었습니다. 물론 중간에 잔인한 장면들이 나와서 눈을 감고 있었지만 박소담이 차를 운전할 때는 저도 같이 타고 있는 듯한 느낌이 들었어요~ 간만에 너무 즐거운 시간 보내고 왔습니다^^', '인생은 아름다워',DEFAULT, 21, 12, '44');	

INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 10.0 ,
	'모든 배우분들 연기 좋았습니다
마지막액션 최고였습니다', '풋사과',DEFAULT, 13, 4, '44');	


INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 10.0 ,
	'어제 시사회 보고 왔어요 . 6세, 7세, 9세 아이들과 함께 봤는데. 
어른 아저씨가 봐도 재미있어요. 아이들은 계속해서 깔깔깔깔.

아이 있는 집은 꼭 보세요~', 'Dr Smith',DEFAULT, 3, 4, '43');

INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 10.0 ,
	'너무  오래 기다렸네요  애들이   극장판 뽀로로 너무 좋아해요   벌써부터  기대하고 있어요 ㅋ', '*^O^*',DEFAULT, 3, 4, '43');	

INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 10.0 ,
	'드래곤 캐슬에서 보물을 찾기 위한 뽀로로와 친구들의 이야기!', '휴면 사용자',DEFAULT, 2, 3, '43');	

INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 10.0 ,
	'아기가 처음 영화관 갔는데
집중해서 끝까지 보네요
뽀통령 최고
(어른인 나도 재밌게 봄)', '바오달터',DEFAULT, 1, 2, '43');	

INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 10.0 ,
	'아이들과 함께 보기 좋아요. 상영시간 내내 깨알같이 개그를 깔아놔서 지루할 틈이 없었습니다. 경험상 뽀로로 극장판 작품은 애들이랑 함께 보기 위해 선택했을 때 실패가 없더라구요.', '김성민',DEFAULT, 1, 2, '43');	

INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 1.0 ,
	'이번 극장판은 좀 별로였다', '나는 단호하게 반대한다',DEFAULT, 0, 1, '43');	

INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 10.0 ,
	'방금 봤는데 이번 극장판은 잘 만들었더군요.
딸도 정말 좋아했어요', '빙그리',DEFAULT, 3, 5, '43');	

INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 10.0 ,
	'기다렸어요!! 이번에도 아이들이 좋아하겠네요', '휴면 사용자',DEFAULT, 2, 4, '43');	

INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 10.0 ,
	'오늘 아이들과 함께 봤는데 저도 아이들도 아주 재미있게 봤습니다  극본,영상 모두 좋았습니다. 믿고 보는 뽀로로입니다. 좋은 영화 감사합니다~^^', '매일꾸준히의위력',DEFAULT, 1, 3, '43');	

INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 10.0 ,
	'오늘  아이하고 보고 왔는데 너무 좋아라 했어요^^', '지니',DEFAULT, 2, 5, '43');	


INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 1.0 ,
	'배우들을 전부 분수대로 만들어 놨네..분수쇼만 보다 나옴.. 정신병자가 만든 영화', '아화',DEFAULT, 125, 62, '42');	

INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 10.0 ,
	'슬래셔 무비 시도 반갑지만, 좀더 영화들 찾아보고 연구해서
이번처럼 맹목적인 작품이 안나오길 기대합니다', '임은석',DEFAULT, 87, 27, '42');	

INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 8.0 ,
	'인간들의  꿈꾸는  영원은 없다.  욕심이 부른 화 로 결국은 이룰수 없다는걸 상기 시켜준 영화인듯^^', '하늘정원',DEFAULT, 71, 25, '42');	

INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 10.0 ,
	'친구는 재미없다하고 난 재밌었다', '마이너리거',DEFAULT, 83, 38, '42');	

INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 9.0 ,
	'화물선이라는 좁은곳에서 이야기가 펼쳐지기에 별기대없이 봤는데 스토리 전개가 상당히 뛰어났습니다. 저는 그냥 형사와 범죄자들의 싸움인줄 알았는데 영화 중간부터 반전도 있고 정말 시간가는줄 모를 정도로 재밌게 봤습니다. 다만, 많이 잔인합니다. 끔찍한 장면 나올때마다 스스로 눈을 감으면서 자체적으로 걸러서 봤습니다. 영화를 보실때 주인공에 이입되어 너무 깊이 보시는분들이라면 정말 불쾌하실수도 있고 대충대충 보시는 분들이라면 괜찮게 보실수 있을겁니다. 다시 한번 말씀드리지만 생각보다 잔인하기에 어느 정도 호러물 보셨던분들이 보시기를 추천합니다. 마녀 시리즈와 비슷한데 마녀시리즈가 순한맛이라면 이건 정말 매운맛입니다. 끔찍한 장면은 눈을 감고 보지말고 어느 정도 마음에 준비는 하시고 보셔요. 잔인해서 별 반개뺍니다', '질풍노도사슴',DEFAULT, 85, 41, '42');	

INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 10.0 ,
	'평점보고 놓칠뻔했습니다 보길잘했네요 슬래셔 무비 매니아들 강추합니다', 'JH',DEFAULT, 75, 31, '42');	

INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 9.0 ,
	'분명 단점이 여러가지 존재하지만 한국에서 이런 장르영화를 만들었다는 것에 점수!', '백발용녀',DEFAULT, 70, 26, '42');	

INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 9.0 ,
	'영화 마녀보다 더 잔인하지만 배우들 연기, 액션 좋고 재밌어요.', '8월의 크리스마스',DEFAULT, 97, 55, '42');	

INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 8.0 ,
	'재미있었어요 잔인함 주의!!!', 'polosso',DEFAULT, 84, 42, '42');	

INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 9.0 ,
	'서인국 배우 연기 변신 너무 최고에요', '아바따라',DEFAULT, 72, 30, '42');	


INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 9.0 ,
	'피로 부활한 21세기 블레이드 버젼~화려한 영상과 퍼포먼스는
충분한 킬링무비로 손색 없다', '바크',DEFAULT, 33, 7, '41');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 9.0 ,
	'저는 시간 가는 줄 모르고 빠져서 봤는데 왜 이렇게 악평이 많을까요? 코로나 시기에 이런 장르의 영화가 오랜만이어서인지 정말 재미있었습니다. 무조건 CG범벅인 영화가 아니어서 더 좋았어요. 그리고 자레드 레토도 멋져요~', 'intolfc',DEFAULT, 32, 12, '41');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 7.0 ,
	'즐겁게 잘 감상했다. 흡력초인이라니..초감각과 비행능력은 좋은데 피를 마셔야 한다는 것이 너무 취약점이네. 그리고 기본적으로 선한데 벌쳐와 팀업을 어케 하려고 쿠키를 저렇게 만들었나 싶네..나중에 또 다른 작품에서 본다면 반가울 듯. 런닝타임이 짧아 신속한 전개가 미덕인데, 빌런과의 싸움이 너무 허접하다. 그외는 볼만함.', '태사다',DEFAULT, 19, default, '41');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 9.0 ,
	'기대를 안해서 그런지 재미있게  봣어요 . 극장에서 봐야 될 영화인듯.  코로나로 인해 간만에 가서 더 좋았는지도..', '조정연',DEFAULT, 21, 3, '41');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 8.0 ,
	'식상한, 혹은 닳고 닳은 전개로 끝나지만 오래된 것을 새로운 방식으로 보여준 것이 참신했달까.   이 장점은 감독의 역량인가 배우의 능력인가.', '현자매미',DEFAULT, 20, 2, '41');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 10.0 ,
	'개봉하자마자 보고 왔다ㅜ 진심 오랜만에 제대로 된 액션 히어로 영화 보고 온듯^^ 이터널쓰땜에 뚁땽했던 마음 모비우스로 치~유~', '소리벗고팬티질러',DEFAULT, 27, 10, '41');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 9.0 ,
	'기대안하고 봐서 그런가. 너무 재밌게 봤음. 담편 기대되요 ㅋㅋ 어글리~ 하지만 매력적인 빌런. 베놈이랑 비슷한 느낌이긴 하지만 또다른 매력이 있음 ㅋ', '망고라임',DEFAULT, 21, 4, '41');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 10.0 ,
	'너무낮은거같아서 실제별은 7.7점정도 주고싶네요
평이너무안좋아서 별로라는걸 베이스로 깔고봐서 그런가?
나쁘지않게 봤습니다. 베놈1편을 재밌게보셨으면 재밌게보실듯 합니다. 베놈2와 이터널스보단 낫습니다. 
개인적으로 베놈1을 재밌게본지라... 기준을 베놈1로 두시고
볼지 말지 판단하시면 좋을듯', '비비',DEFAULT, 21, 5, '41');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 10.0 ,
	'나름 생각보다 재미있게 봤네요...이렇게 눈이 즐거운 영화가 재미 없다고하면 예술영화나 봐야죠', '터프가이',DEFAULT, 19, 3, '41');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 9.0 ,
	'재밌다. 화려면 영상과 액션만으로 볼만하다. 요즘처럼 쓰레기 영화 홍수속에 돋보이는 평작', 'LUST',DEFAULT, 18, 2, '41');	


INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 5.0 ,
	'윤재앙 탄핵 콜 걸 접대부 쥴리 구속 -끝-', '영화는 역시 토렌트',DEFAULT, 153, 89, '40');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 1.0 ,
	'정말 원작이 너무 아깝네요.  스토리 전개가 아쉽고  툭툭 끊어지는건 그렇다치고 당시에도 채팅에서나 쓰던 말들을 구어체인듯 사용하는게 너무 거슬려서 보다가 포기했습니다. 당시를 살아본 사람이 쓴 시나리오가 아니라 당시의 시대상을 글로 읽은 사람이 시나리오를 쓴 것 같아요. (전 98학번입니다.)', 'DO',DEFAULT, 27, 4, '40');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 1.0 ,
	'이런거 진짜 안다는데 보고싶다고 애들 델꼬 영화 보러가서 사과했습니다.  뭘 전달하려는지도 모르겠고 내용 전개도 매끄럽지 못해서 집중도 안됩니다. 2022년도 최악의 영화입니다 비추합니다', '김진혁',DEFAULT, 34, 14, '40');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 4.0 ,
	'나이가 먹어서 그런지 20여년전 원작이 더 나은 듯....', '효니지니',DEFAULT, 20, 2, '40');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 2.0 ,
	'감독님ㅠㅠ 대사가 캐릭터랑 따로 놀아서 감정이입이 되지 않네요.;;;; 그리고 미장센이 툭툭 튀어서 흐름상 매끄럽지 못해요.;; 평소 하고싶던 플롯을 이어붙인 느낌입니다아... 그래서 배우들의 연기가 따로 노는 느낌이 들어요. 뭐 화이팅입니다.', '용리',DEFAULT, 26, 11, '40');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 1.0 ,
	'이게 뭔가 싶은 영화', '은수',DEFAULT, 17, 4, '40');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 10.0 ,
	'여진구님 출연한다니 빨리 보고 싶어요^^', '김경애',DEFAULT, 22, 10, '40');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 5.0 ,
	'99학번들을 많이 유치하게 표현하는데 "방가&방가방가,"같은 말을 너무 어색하게 쓰다보니 보는 내내 좀 불편했음 그리고 스토리를 쫌 꼬아서인지 남주가 불쌍보단 짜증날때가 생겨서  몰입감이 깨진다. 

현제 쪽도 여주가 투머치토커고 가벼워서 진한 감정이 부족해보여서 과거 동감에서의 애뜻함과 안타까움을 공감하던 감성에 찬물을  부어버린다.

중후반도 아름다운 마무리가 아닌 찌질이의 자기 파괴적 집착과 포기만남은 영화

결말도 가벼워진 요즘 트렌드를 따르다 보니  과거 동감을 추억하는 사람은 안보는 것이 기존의 감동을 유지하는데 도움 이 될듯 하다.', '천낙',DEFAULT, 16, 4, '40');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 10.0 ,
	'여진구 보다가 시간 다 가버렷습니다,,,,찌질했다가 귀여웠다가 멋있었다가 다해버려요ㅠ김혜윤님이랑 케미도 너무 좋더라구요ㅠㅠㅠㅠ옛날 생각나요ㅠㅠ진짜 그럼 바이루', 'bora3539',DEFAULT, 23, 12, '40');	
INSERT INTO tblreview (reviewseq, reviewrate, reviewcontent, id, postdate, good, bad,seq) 
	VALUES (reviewseq.nextVal, 8.0 ,
	'저도 95학번 입니다 ㅎㅎㅎㅎ
옛날에 이 영화 감동이었는데 …
ost 까지 … 진구님 보러 가야갰어요', 'younggirl',DEFAULT, 20, 11, '40');	